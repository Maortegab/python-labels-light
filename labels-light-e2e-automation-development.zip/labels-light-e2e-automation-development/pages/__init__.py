"""
        * Admin folder refers to pages in url: https://sb-app.soloenvios.com/es-MX/corporate/*
        * User folder refers to pages in url: https://sb-app.soloenvios.com/es-MX/
        * login_page.py file refers to login page that are common used by normal and admin users: https://sb-app.soloenvios.com/es-MX/users/sign_in
"""
