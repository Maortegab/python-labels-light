class TextPages:
    API_DOCS_TITLE: str = "Bienvenido a la documentación de nuestra API"
    ADDRESS_TEMPLATES_TITLE: str = "Libreta de direcciones"
